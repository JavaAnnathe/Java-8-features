package com.training;

import java.util.function.Function;

public class Main {

	public static void main(String[] args) {
		
		//FunctionImpl f = new FunctionImpl();
		
		//Integer i = f.apply(10);
		
		//System.out.println(i);
		
		Function<Integer,Integer> f = (i)->i*i;
		
		Integer i = f.apply(15);
		System.out.println(i);

	}

}
