package com.training;

import java.util.function.Function;

public class FunctionImpl implements Function<Integer,Integer>{

	@Override
	public Integer apply(Integer i) {
		
		return i * i;
	}

}
