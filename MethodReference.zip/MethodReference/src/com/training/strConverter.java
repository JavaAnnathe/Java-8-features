package com.training;

public class strConverter {
	
	public static String changeText(String s){
		
		return s.toUpperCase();
	}

}
