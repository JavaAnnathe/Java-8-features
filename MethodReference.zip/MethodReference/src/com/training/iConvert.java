package com.training;

public interface iConvert {
	
	public String convert(String s);

}
