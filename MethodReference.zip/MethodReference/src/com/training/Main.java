package com.training;

public class Main {
	
	public static String doIt(iConvert ic, String s){
		
		return ic.convert(s);
	}

	public static void main(String[] args) {
		
		
		String result = doIt(strConverter::changeText,"welcome");
		
		System.out.println(result);

	}

}
