package com.training;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class Main1 {

	public static void main(String[] args) {
		
		List<String> names = new ArrayList<String>();
		
		names.add("Kumar");
		names.add("Geetha");
		
		Stream<String> s = names.stream();
		
		long count =s.count();
		System.out.println(count);
		
		Stream<Integer> s1 = Stream.of(1,2,3,4,5);
		
		System.out.println(s1.count());
		
		
	}

}
