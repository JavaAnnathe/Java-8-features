package com.training;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Main2 {

	public static void main(String[] args) {
		
		//create an arraylist of integers
		List<Integer> numList = new ArrayList<Integer>();
		numList.add(1);
		numList.add(2);
		numList.add(3);
		numList.add(4);
		numList.add(5);
		
		System.out.println(numList.stream().map((i)->i*i).filter((i)->i>10).count());
		
				
				//create a stream from this arraylist
		//Stream<Integer> s1 = numList.stream();
		//convert this stream into another stream
		//Function<Integer,Integer> f=(i)->i*i;		
		//Stream<Integer> s2 =s1.map(f);
		//filter the stream and form another stream
		//Predicate<Integer> p = (i)->i>10;
		//Stream<Integer> s3 = s2.filter(p);
		
		//long count = s3.count();
		
		//System.out.println(count);
		
		
	}

}
