package com.training;

import java.util.Arrays;
import java.util.stream.Stream;

public class Main {

	public static void main(String[] args) {
		
		Integer[] num = {1,2,3,4};
		
		Stream<Integer> s1 = Arrays.stream(num);
		
		long count = s1.count();
		System.out.println(count);
		
		
		
		
	}

}
