package com.training;

public class MyNumeric implements Numeric{
	
	public int getValue(int i){
		
		return i*i;
	}

}
