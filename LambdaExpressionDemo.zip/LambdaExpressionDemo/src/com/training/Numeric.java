package com.training;

public interface Numeric {
	
	public int getValue(int i);

}
