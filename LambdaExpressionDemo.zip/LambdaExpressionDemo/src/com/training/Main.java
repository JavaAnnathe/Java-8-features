package com.training;

public class Main {

	public static void main(String[] args) {
		
		MyNumeric m = new MyNumeric();
		
		int result=m.getValue(5);
		
		//System.out.println(result);
		
		Numeric n=( i)->i*i;
		
		int r=n.getValue(5);
		
		System.out.println(r);
		
		

	}

}
