package com.training;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Numeric n=(i)->{
			
			int result=i*i;
			 result++;
			 return result;			
			
		}; 
		
		int output = n.getValue(10);
		
		System.out.println(output);

	}

}
