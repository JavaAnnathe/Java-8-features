package com.training;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Tester t = new Tester();
		
	boolean b=	t.testEven((i)->i%2==0, 5);
	
	System.out.println("The number is even:"+b);

	}

}
