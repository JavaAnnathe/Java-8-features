package com.training;

public interface NumericTest {
	
	public boolean find(int i);

}
