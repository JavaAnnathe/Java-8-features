package com.training;

public class Tester {
	
	public boolean testEven(NumericTest n,int i){
		
		boolean b =n.find(i);
		
		return b;
	}

}
