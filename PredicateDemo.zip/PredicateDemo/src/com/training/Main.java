package com.training;

import java.util.function.Predicate;

public class Main {

	public static void main(String[] args) {
		//PredicateImpl p = new PredicateImpl();
		
		//boolean b = p.test(-5);
		
		//System.out.println("Value is greater than 0:"+b);
		
		Predicate<Integer> p=(i)->i>0;
		
		boolean b = p.test(8);
		
		System.out.println("Value is greater than 0:"+b);

	}

}
