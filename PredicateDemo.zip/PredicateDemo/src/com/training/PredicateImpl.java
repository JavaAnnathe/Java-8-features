package com.training;

import java.util.function.Predicate;

public class PredicateImpl implements Predicate<Integer>{

	@Override
	public boolean test(Integer i) {
		boolean b = i>0;
		
		return b;
	}

}
