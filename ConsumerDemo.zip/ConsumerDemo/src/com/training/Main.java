package com.training;

import java.util.function.Consumer;

public class Main {

	public static void main(String[] args) {
		
		//ConsumerImpl c = new ConsumerImpl();
		
		//c.accept("Java is easy to learn");
		
		Consumer<String> c=(s)->System.out.println(s);
		
		c.accept("Welcome to the world of IT Industry");
		
		

	}

}
