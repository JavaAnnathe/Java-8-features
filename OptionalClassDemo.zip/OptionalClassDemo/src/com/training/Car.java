package com.training;

public class Car {
	
	private String brand;
	private String model;
	private String registrationNo;
	
	public Car(String brand, String model, String registrationNo) {
		
		this.brand = brand;
		this.model = model;
		this.registrationNo = registrationNo;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getRegistrationNo() {
		return registrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}
	
	public void showDetails(){
		
		System.out.println("Registration Id:"+this.getRegistrationNo());
		System.out.println("Brand:"+this.getBrand());
		System.out.println("Model:"+this.getModel());
	}
	

}
