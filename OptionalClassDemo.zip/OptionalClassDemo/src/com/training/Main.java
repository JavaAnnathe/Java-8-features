package com.training;

import java.util.Optional;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Car c = new Car("TN33AB45","Honda","city");
		Car c1=null;
		
		MechanicShop m = new MechanicShop();
		
		Optional<Car> o =Optional.ofNullable(c) ;
		
		m.doService(o);

	}

}
