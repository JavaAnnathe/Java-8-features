package com.training;

import java.util.Optional;

public class MechanicShop {
	
	public void doService(Optional<Car> op){
		
		if(op.isPresent()){
		
		Car c = op.get();
		
		c.showDetails();
		}
		else{
			
			System.out.println("Car object is null");
		}
		
		
	}

}
