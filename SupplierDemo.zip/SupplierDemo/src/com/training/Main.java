package com.training;

import java.util.function.Supplier;

public class Main {

	public static void main(String[] args) {
		
		//Supplier<Integer> s = new SupplierImpl();
		
		//Integer i =s.get();
		
		//System.out.println(i);
		
		Supplier<Integer> s=()->1456;
		
		Integer i =s.get();
		
		System.out.println(i);
		

	}

}
