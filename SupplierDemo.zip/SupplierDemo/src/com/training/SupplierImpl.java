package com.training;

import java.util.function.Supplier;

public class SupplierImpl implements Supplier<Integer>{

	@Override
	public Integer get() {
		
		return 1456;
	}

}
